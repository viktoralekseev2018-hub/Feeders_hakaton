import { ArrowRight, Clock3 } from "lucide-react"

const courses = [
  {
    title: "Весенний курс подготовки к ОГЭ по математике — 2027",
    description: "Системный разбор первой части, геометрии и основных заданий повышенной сложности.",
    status: "СКОРО",
    tag: "9 класс · ОГЭ",
  },
  {
    title: "Годовой курс подготовки к ЕГЭ по профильной математике — 2027",
    description: "Последовательная подготовка от базовых тем до сложных задач второй части.",
    status: "В РАЗРАБОТКЕ",
    tag: "11 класс · ЕГЭ",
  },
  {
    title: "Летний курс: уверенный переход в 9 класс",
    description: "Повторение ключевых тем 7–8 классов и подготовка базы для будущего ОГЭ.",
    status: "СКОРО",
    tag: "8–9 класс",
  },
  {
    title: "Математика с нуля: база 7–8 класса",
    description: "Понятный маршрут для тех, кто хочет восстановить пропуски и уверенно двигаться дальше.",
    status: "НАБОР ПОЗЖЕ",
    tag: "7–8 класс",
  },
]

export function CoursesSection() {
  return (
    <section id="courses" className="scroll-mt-24 px-4 py-20 sm:px-6 sm:py-28">
      <div className="mx-auto max-w-7xl">
        <div className="mb-10 max-w-3xl space-y-4 sm:mb-14">
          <p className="font-mono text-xs uppercase tracking-[0.35em] text-primary">COURSES</p>
          <h2 className="text-4xl font-bold tracking-tight sm:text-5xl">Программы подготовки</h2>
          <p className="text-base leading-7 text-muted-foreground sm:text-lg">
            Будущие программы системной подготовки по школьной математике, ОГЭ и ЕГЭ.
          </p>
        </div>

        <div className="grid gap-5 md:grid-cols-2">
          {courses.map((course) => (
            <article
              key={course.title}
              className="course-card group relative min-h-72 overflow-hidden rounded-xl border border-border/70 bg-card/45 p-7 transition-all duration-300 hover:-translate-y-1 hover:border-primary/55 hover:bg-card/80"
            >
              <div className="mb-9 flex items-start justify-between gap-4">
                <span className="rounded-md border border-border bg-secondary/55 px-3 py-1.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                  {course.tag}
                </span>
                <span className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-wider text-primary">
                  <Clock3 className="h-3.5 w-3.5" />
                  {course.status}
                </span>
              </div>
              <h3 className="mb-4 max-w-xl text-xl font-bold leading-snug tracking-tight transition-colors group-hover:text-primary sm:text-2xl">
                {course.title}
              </h3>
              <p className="max-w-2xl text-sm leading-6 text-muted-foreground">{course.description}</p>
              <span className="absolute bottom-7 left-7 flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-muted-foreground">
                ПОДРОБНЕЕ СКОРО
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </span>
              <span className="card-accent-line" aria-hidden="true" />
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
