import { CheckCircle2 } from "lucide-react"

const steps = [
  "Выбираешь класс и тему",
  "Изучаешь короткое объяснение",
  "Решаешь задания",
  "Разбираешь ошибки",
  "Переходишь к следующей теме",
]

export function AboutSection() {
  return (
    <section id="about" className="scroll-mt-24 px-4 py-20 sm:px-6 sm:py-28">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-10 lg:grid-cols-[1.05fr_0.95fr] lg:items-stretch">
          <div className="rounded-2xl border border-border/70 bg-card/40 p-7 sm:p-10">
            <p className="mb-4 font-mono text-xs uppercase tracking-[0.35em] text-primary">ABOUT FIZMA</p>
            <h2 className="mb-7 text-4xl font-bold tracking-tight sm:text-5xl">
              Платформа для понятной математики
            </h2>
            <div className="space-y-5 text-base leading-8 text-muted-foreground">
              <p>
                FIZMA — образовательная платформа для учеников 6–11 классов. Здесь математика объясняется простым языком: через понимание, последовательную практику и разбор ошибок.
              </p>
              <p>
                Платформа создана студентом МГТУ им. Н. Э. Баумана и выпускником Бауманского инженерного лицея с опытом преподавания математики и физики.
              </p>
            </div>

            <div className="mt-9 space-y-3">
              {steps.map((step, index) => (
                <div key={step} className="flex items-center gap-3 rounded-lg border border-border/60 bg-secondary/25 px-4 py-3">
                  <span className="font-mono text-xs text-primary">0{index + 1}</span>
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  <span className="text-sm text-foreground">{step}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="relative overflow-hidden rounded-2xl border border-primary/35 bg-card/50 p-7 sm:p-10">
            <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent" />
            <div className="mb-8 flex items-center gap-2" aria-hidden="true">
              <span className="h-2.5 w-2.5 rounded-full bg-red-500/60" />
              <span className="h-2.5 w-2.5 rounded-full bg-yellow-500/60" />
              <span className="h-2.5 w-2.5 rounded-full bg-primary/70" />
            </div>
            <p className="mb-8 font-mono text-xs text-muted-foreground">terminal://fizma/about</p>
            <div className="space-y-4 font-mono text-sm leading-7">
              <p><span className="text-primary">&gt;</span> university: bmstu</p>
              <p><span className="text-primary">&gt;</span> background: bauman engineering lyceum</p>
              <p><span className="text-primary">&gt;</span> teaching experience: 2+ years</p>
              <p><span className="text-primary">&gt;</span> current subject: mathematics</p>
              <p><span className="text-primary">&gt;</span> approach: simple explanations</p>
              <p><span className="text-primary">&gt;</span> mission: understand, not memorize</p>
            </div>
            <div className="mt-12 border-t border-border/60 pt-6 font-mono text-xs text-primary">
              status: building a better way to learn_
            </div>
            <div className="absolute -bottom-24 -right-24 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
          </div>
        </div>
      </div>
    </section>
  )
}
