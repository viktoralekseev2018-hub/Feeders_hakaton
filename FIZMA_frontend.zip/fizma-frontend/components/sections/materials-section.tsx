import { ArrowUpRight } from "lucide-react"

const materials = [
  {
    category: "основа",
    title: "Как перестать ошибаться в дробях",
    description: "Разбираем порядок действий, общий знаменатель и привычки, которые снижают количество случайных ошибок.",
  },
  {
    category: "огэ",
    title: "Что нужно знать перед началом подготовки к ОГЭ",
    description: "Какие темы проверить в первую очередь и как построить подготовку без хаотичного решения вариантов.",
  },
  {
    category: "обучение",
    title: "Почему формулы лучше понимать, чем запоминать",
    description: "Показываем, как смысл формулы помогает восстановить её даже тогда, когда запись забылась.",
  },
  {
    category: "практика",
    title: "Как правильно разбирать ошибки после решения задач",
    description: "Простой алгоритм: найти причину, восстановить ход решения и закрепить похожей задачей.",
  },
]

export function MaterialsSection() {
  return (
    <section id="materials" className="scroll-mt-24 px-4 py-20 sm:px-6 sm:py-28">
      <div className="mx-auto max-w-7xl">
        <div className="mb-10 max-w-3xl space-y-4 sm:mb-14">
          <p className="font-mono text-xs uppercase tracking-[0.35em] text-primary">MATERIALS</p>
          <h2 className="text-4xl font-bold tracking-tight sm:text-5xl">Полезные разборы</h2>
          <p className="text-base leading-7 text-muted-foreground sm:text-lg">
            Короткие материалы о том, как понимать математику, избегать типичных ошибок и готовиться системно.
          </p>
        </div>

        <div className="grid gap-5 md:grid-cols-2">
          {materials.map((material, index) => (
            <article
              key={material.title}
              className="group relative min-h-64 overflow-hidden rounded-xl border border-border/70 bg-card/40 p-7 transition-all duration-300 hover:border-primary/50 hover:bg-gradient-to-br hover:from-primary/10 hover:via-card/70 hover:to-primary/5"
            >
              <div className="mb-8 flex items-center justify-between">
                <span className="rounded-lg border border-border bg-secondary/55 px-3 py-1.5 font-mono text-[10px] lowercase text-muted-foreground transition-colors group-hover:border-primary/40 group-hover:text-primary">
                  {material.category}
                </span>
                <span className="font-mono text-xs text-muted-foreground">0{index + 1}</span>
              </div>
              <h3 className="mb-4 text-xl font-bold tracking-tight sm:text-2xl">{material.title}</h3>
              <p className="max-w-2xl text-sm leading-6 text-muted-foreground">{material.description}</p>
              <span className="absolute bottom-7 left-7 inline-flex items-center gap-2 font-mono text-xs text-primary opacity-0 transition-all duration-300 group-hover:opacity-100">
                read later
                <ArrowUpRight className="h-4 w-4" />
              </span>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
