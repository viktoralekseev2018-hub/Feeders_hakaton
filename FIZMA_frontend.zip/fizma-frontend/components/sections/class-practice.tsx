"use client"

import { useEffect, useMemo, useState } from "react"
import Link from "next/link"
import { ArrowLeft, ArrowRight, BookOpen, LockKeyhole } from "lucide-react"

const grades = [
  {
    id: "6",
    title: "6 КЛАСС",
    subtitle: "Основа школьной математики",
    description: "Дроби, проценты, уравнения, текстовые задачи и геометрия.",
    topics: [
      "Натуральные числа",
      "Обыкновенные дроби",
      "Десятичные дроби",
      "Проценты",
      "Отношения и пропорции",
      "Уравнения",
      "Координатная плоскость",
      "Текстовые задачи",
      "Основы геометрии",
    ],
  },
  {
    id: "7",
    title: "7 КЛАСС",
    subtitle: "Переход к алгебре",
    description: "Степени, многочлены, линейные уравнения, функции и геометрия.",
    topics: [
      "Степени",
      "Одночлены и многочлены",
      "Формулы сокращённого умножения",
      "Линейные уравнения",
      "Системы уравнений",
      "Функции и графики",
      "Текстовые задачи",
      "Геометрия",
    ],
  },
  {
    id: "8",
    title: "8 КЛАСС",
    subtitle: "Уверенная база перед ОГЭ",
    description: "Квадратные корни, уравнения, неравенства, функции и геометрия.",
    topics: [
      "Рациональные дроби",
      "Квадратные корни",
      "Квадратные уравнения",
      "Неравенства",
      "Системы уравнений",
      "Функции",
      "Вероятность",
      "Геометрия",
    ],
  },
  {
    id: "9",
    title: "9 КЛАСС · ОГЭ",
    subtitle: "Подготовка к экзамену",
    description: "Первая часть, геометрия, текстовые задачи и задания повышенной сложности.",
    topics: [
      "Числа и вычисления",
      "Алгебраические выражения",
      "Уравнения и системы",
      "Неравенства",
      "Функции и графики",
      "Текстовые задачи",
      "Вероятность и статистика",
      "Геометрия",
      "Варианты ОГЭ",
    ],
  },
  {
    id: "10",
    title: "10 КЛАСС",
    subtitle: "Системная подготовка",
    description: "Функции, тригонометрия, вероятность, планиметрия и стереометрия.",
    topics: [
      "Функции",
      "Тригонометрия",
      "Уравнения",
      "Неравенства",
      "Производная: введение",
      "Вероятность и комбинаторика",
      "Планиметрия",
      "Стереометрия",
    ],
  },
  {
    id: "11",
    title: "11 КЛАСС · ЕГЭ",
    subtitle: "Подготовка к ЕГЭ",
    description: "Профильная математика, сложные уравнения, геометрия, параметры и практика вариантов.",
    topics: [
      "Уравнения",
      "Неравенства",
      "Функции и производная",
      "Тригонометрия",
      "Вероятность",
      "Финансовая математика",
      "Планиметрия",
      "Стереометрия",
      "Параметры",
      "Варианты ЕГЭ",
    ],
  },
]

function gradeFromHash() {
  if (typeof window === "undefined") return null
  const match = window.location.hash.match(/^#tasks\/(6|7|8|9|10|11)$/)
  return match?.[1] ?? null
}

export function ClassPractice() {
  const [selectedGradeId, setSelectedGradeId] = useState<string | null>(null)

  useEffect(() => {
    const syncWithUrl = () => setSelectedGradeId(gradeFromHash())
    syncWithUrl()
    window.addEventListener("hashchange", syncWithUrl)
    window.addEventListener("popstate", syncWithUrl)
    return () => {
      window.removeEventListener("hashchange", syncWithUrl)
      window.removeEventListener("popstate", syncWithUrl)
    }
  }, [])

  const selectedGrade = useMemo(
    () => grades.find((grade) => grade.id === selectedGradeId) ?? null,
    [selectedGradeId],
  )

  const openGrade = (gradeId: string) => {
    window.history.pushState({ gradeId }, "", `#tasks/${gradeId}`)
    setSelectedGradeId(gradeId)
    document.getElementById("tasks")?.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  const closeGrade = () => {
    window.history.pushState({}, "", "#tasks")
    setSelectedGradeId(null)
    document.getElementById("tasks")?.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  return (
    <section id="tasks" className="scroll-mt-24 px-4 py-20 sm:px-6 sm:py-28">
      <div className="mx-auto max-w-7xl">
        {!selectedGrade ? (
          <>
            <div className="mb-10 max-w-3xl space-y-4 sm:mb-14">
              <p className="font-mono text-xs uppercase tracking-[0.35em] text-primary">PRACTICE</p>
              <h2 className="text-4xl font-bold tracking-tight sm:text-5xl">Выбери свой класс</h2>
              <p className="text-base leading-7 text-muted-foreground sm:text-lg">
                Выбери класс, затем тему и начни последовательную подготовку по математике.
              </p>
            </div>

            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {grades.map((grade, index) => (
                <button
                  key={grade.id}
                  type="button"
                  onClick={() => openGrade(grade.id)}
                  className="course-card group relative min-h-72 overflow-hidden rounded-xl border border-border/70 bg-card/45 p-7 text-left backdrop-blur-sm transition-all duration-400 hover:-translate-y-1 hover:border-primary/55 hover:bg-card/80 hover:shadow-2xl hover:shadow-black/10"
                  style={{ animationDelay: `${index * 80}ms` }}
                >
                  <span className="mb-8 inline-flex rounded-full border border-primary/35 bg-primary/10 px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.2em] text-primary">
                    mathematics
                  </span>
                  <h3 className="mb-3 text-2xl font-bold tracking-tight transition-colors group-hover:text-primary">
                    {grade.title}
                  </h3>
                  <p className="mb-3 font-medium text-foreground">{grade.subtitle}</p>
                  <p className="text-sm leading-6 text-muted-foreground">{grade.description}</p>
                  <span className="absolute bottom-7 left-7 flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-primary">
                    Выбрать темы
                    <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
                  </span>
                  <span className="card-accent-line" aria-hidden="true" />
                </button>
              ))}
            </div>
          </>
        ) : (
          <div className="animate-fade-in-up">
            <button
              type="button"
              onClick={closeGrade}
              className="mb-8 inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2.5 font-mono text-xs text-muted-foreground transition-colors hover:border-primary/60 hover:bg-primary/10 hover:text-primary"
            >
              <ArrowLeft className="h-4 w-4" />
              НАЗАД К КЛАССАМ
            </button>

            <div className="mb-10 grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
              <div className="space-y-4">
                <p className="font-mono text-xs uppercase tracking-[0.35em] text-primary">TOPICS</p>
                <h2 className="text-4xl font-bold tracking-tight sm:text-5xl">{selectedGrade.title}</h2>
                <p className="text-lg text-muted-foreground">Темы по математике</p>
              </div>
              <div className="rounded-lg border border-primary/35 bg-primary/10 px-4 py-3 font-mono text-xs text-primary">
                {selectedGrade.topics.length} тем · демонстрационный каталог
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {selectedGrade.topics.map((topic, index) => (
                <article
                  key={topic}
                  className="course-card group relative flex min-h-52 flex-col overflow-hidden rounded-xl border border-border/70 bg-card/45 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-primary/50 hover:bg-card/75"
                >
                  <div className="mb-8 flex items-center justify-between">
                    <span className="font-mono text-xs text-muted-foreground">{String(index + 1).padStart(2, "0")}</span>
                    <BookOpen className="h-4 w-4 text-primary" />
                  </div>
                  <h3 className="mb-4 text-lg font-semibold tracking-tight transition-colors group-hover:text-primary">
                    {topic}
                  </h3>
                  <Link
                    href="/register"
                    className="mt-auto inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-primary"
                  >
                    НАЧАТЬ РЕШАТЬ
                    <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
                  </Link>
                  <span className="card-accent-line" aria-hidden="true" />
                </article>
              ))}
            </div>

            <div className="mt-8 flex items-start gap-3 rounded-xl border border-border/70 bg-secondary/30 p-5 text-sm leading-6 text-muted-foreground">
              <LockKeyhole className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <p>
                Создай аккаунт, чтобы решать задания, сохранять результаты и отслеживать прогресс. Сейчас каталог тем работает как демонстрация будущего раздела.
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  )
}
