"use client"

import { useEffect, useState } from "react"

const terminalLines = [
  "> subject: mathematics",
  "> grades: 6–11",
  "> format: theory + practice",
  "> goal: understand, not memorize",
  "> status: learning",
]

export function HeroSection() {
  const [visibleLines, setVisibleLines] = useState(0)

  useEffect(() => {
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    if (reducedMotion) {
      setVisibleLines(terminalLines.length)
      return
    }

    const timers = terminalLines.map((_, index) =>
      window.setTimeout(() => setVisibleLines(index + 1), 650 + index * 430),
    )

    return () => timers.forEach((timer) => window.clearTimeout(timer))
  }, [])

  return (
    <section id="home" className="relative scroll-mt-24 px-4 pb-20 pt-32 sm:px-6 sm:pb-28 sm:pt-40">
      <div className="mx-auto max-w-7xl">
        <div className="grid min-h-[72vh] items-center gap-14 lg:grid-cols-[1.02fr_0.98fr] lg:gap-20">
          <div className="space-y-8 sm:space-y-10">
            <div className="space-y-4 animate-fade-in-up">
              <p className="font-mono text-xs uppercase tracking-[0.25em] text-primary sm:tracking-[0.35em]">
                Mathematics learning platform
              </p>
              <h1 className="text-balance text-5xl font-bold leading-[0.98] tracking-tight sm:text-6xl lg:text-7xl">
                WELCOME TO
                <br />
                <span className="typing-cursor text-primary">fizma_</span>
              </h1>
            </div>

            <div className="max-w-xl space-y-4 animate-fade-in-up stagger-2">
              <p className="text-xl font-medium leading-relaxed text-foreground sm:text-2xl">
                Понимай математику, а не заучивай её.
              </p>
              <p className="text-base leading-7 text-muted-foreground sm:text-lg">
                Задачи, понятная теория и подготовка для учеников 6–11 классов — от школьной программы до ОГЭ и ЕГЭ.
              </p>
              <p className="border-l border-primary/50 pl-4 text-sm leading-6 text-muted-foreground">
                Платформа создана студентом МГТУ им. Н. Э. Баумана и выпускником Бауманского инженерного лицея с опытом преподавания.
              </p>
            </div>

            <div className="flex flex-col gap-4 sm:flex-row animate-fade-in-up stagger-3">
              <a
                href="#tasks"
                className="group relative inline-flex items-center justify-center gap-3 overflow-hidden rounded-lg border border-primary bg-primary/10 px-7 py-4 font-mono text-sm text-primary transition-all duration-500 hover:text-primary-foreground active:scale-[0.98]"
              >
                <span className="absolute inset-0 -translate-x-full bg-primary transition-transform duration-500 group-hover:translate-x-0" />
                <span className="relative z-10">НАЧАТЬ ПОДГОТОВКУ</span>
                <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">→</span>
              </a>
              <a
                href="#about"
                className="group inline-flex items-center justify-center gap-3 rounded-lg border border-border px-7 py-4 font-mono text-sm text-muted-foreground transition-all duration-300 hover:border-foreground/70 hover:bg-secondary/50 hover:text-foreground active:scale-[0.98]"
              >
                О ПЛАТФОРМЕ
                <span className="-translate-x-2 opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100">→</span>
              </a>
            </div>
          </div>

          <div className="relative animate-scale-in stagger-4">
            <div className="terminal-panel relative overflow-hidden rounded-2xl border border-border bg-card/55 p-5 shadow-2xl shadow-black/10 backdrop-blur-xl sm:p-8">
              <div className="absolute left-4 top-4 flex items-center gap-2" aria-hidden="true">
                <span className="h-3 w-3 rounded-full bg-red-500/65" />
                <span className="h-3 w-3 rounded-full bg-yellow-500/65" />
                <span className="h-3 w-3 rounded-full bg-primary/70" />
              </div>
              <div className="absolute left-1/2 top-3.5 -translate-x-1/2 rounded-md bg-background/60 px-3 py-1 font-mono text-[11px] text-muted-foreground">
                terminal://fizma
              </div>

              <div className="mt-10 rounded-lg border border-primary/65 bg-background/25 p-4 sm:p-6">
                <pre className="overflow-hidden font-mono text-[9px] leading-tight text-primary sm:text-xs md:text-[13px]">
{`███████╗██╗███████╗███╗   ███╗ █████╗
██╔════╝██║╚══███╔╝████╗ ████║██╔══██╗
█████╗  ██║  ███╔╝ ██╔████╔██║███████║
██╔══╝  ██║ ███╔╝  ██║╚██╔╝██║██╔══██║
██║     ██║███████╗██║ ╚═╝ ██║██║  ██║
╚═╝     ╚═╝╚══════╝╚═╝     ╚═╝╚═╝  ╚═╝`}
                </pre>

                <div className="mt-7 space-y-2.5 font-mono text-xs sm:text-sm">
                  {terminalLines.map((line, index) => (
                    <p
                      key={line}
                      className={
                        index < visibleLines
                          ? "translate-y-0 text-primary opacity-100 transition-all duration-500"
                          : "translate-y-2 opacity-0"
                      }
                    >
                      {line}
                    </p>
                  ))}
                </div>
              </div>
            </div>

            <div className="absolute -right-2 -top-4 rounded-lg border border-primary/45 bg-primary/15 px-4 py-2 font-mono text-xs text-primary backdrop-blur-lg sm:-right-6">
              <span className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
                mathematics://online
              </span>
            </div>
            <div className="absolute -bottom-4 -left-2 rounded-lg border border-border bg-card/85 px-4 py-2 font-mono text-xs text-muted-foreground backdrop-blur-lg sm:-left-6">
              grades 6—11
            </div>
            <div className="absolute -z-10 left-1/2 top-1/2 h-[120%] w-[120%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/5 blur-3xl" />
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 lg:flex">
        <span className="font-mono text-xs text-muted-foreground">scroll</span>
        <span className="h-12 w-px animate-pulse bg-gradient-to-b from-primary/60 to-transparent" />
      </div>
    </section>
  )
}
