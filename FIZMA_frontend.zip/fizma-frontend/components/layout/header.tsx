"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { LogIn, Menu, X } from "lucide-react"
import { cn } from "@/lib/utils/utils"
import { ThemeChanger } from "@/components/ui/theme-changer"
import { ThemeToggle } from "@/components/ui/theme-toggle"

const navItems = [
  { label: "HOME", href: "/#home", section: "home" },
  { label: "TASKS", href: "/#tasks", section: "tasks" },
  { label: "COURSES", href: "/#courses", section: "courses" },
  { label: "MATERIALS", href: "/#materials", section: "materials" },
  { label: "ABOUT", href: "/#about", section: "about" },
]

export function Header() {
  const pathname = usePathname()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const [activeSection, setActiveSection] = useState("home")

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 18)
    handleScroll()
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    if (pathname !== "/") return

    const sections = navItems
      .map((item) => document.getElementById(item.section))
      .filter((section): section is HTMLElement => section !== null)

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0]

        if (visible?.target.id) setActiveSection(visible.target.id)
      },
      { rootMargin: "-35% 0px -55% 0px", threshold: [0.05, 0.2, 0.5] },
    )

    sections.forEach((section) => observer.observe(section))
    return () => observer.disconnect()
  }, [pathname])

  const isActive = (section: string) => pathname === "/" && activeSection === section

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        isScrolled
          ? "border-b border-border/70 bg-background/85 shadow-sm backdrop-blur-xl"
          : "bg-transparent",
      )}
    >
      <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6">
        <nav className="flex items-center justify-between" aria-label="Главная навигация">
          <Link href="/" className="group flex items-center gap-3" aria-label="fizma — на главную">
            <span className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-primary/55 bg-primary/10 font-mono text-sm text-primary transition-all duration-300 group-hover:scale-105 group-hover:border-primary group-hover:bg-primary group-hover:text-primary-foreground group-hover:shadow-lg group-hover:shadow-primary/20">
              <span className="glitch" aria-hidden="true">ƒ</span>
            </span>
            <span className="font-mono text-base font-semibold tracking-tight text-foreground">
              fiz<span className="text-primary">ma</span>
            </span>
          </Link>

          <div className="hidden items-center gap-1 lg:flex">
            {navItems.map((item) => (
              <a
                key={item.section}
                href={item.href}
                className={cn(
                  "group relative rounded-lg px-3 py-2.5 font-mono text-[11px] uppercase tracking-[0.17em] transition-colors",
                  isActive(item.section)
                    ? "text-primary"
                    : "text-muted-foreground hover:bg-secondary/55 hover:text-foreground",
                )}
              >
                <span className="transition-transform duration-200 group-hover:translate-x-1">{item.label}</span>
                <span
                  className={cn(
                    "absolute bottom-1 left-1/2 h-0.5 -translate-x-1/2 rounded-full bg-primary transition-all duration-300",
                    isActive(item.section) ? "w-7" : "w-0 group-hover:w-7",
                  )}
                />
              </a>
            ))}
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <div className="hidden items-center gap-1 sm:flex">
              <ThemeChanger />
              <ThemeToggle />
            </div>

            <Link
              href="/login"
              className={cn(
                "hidden items-center gap-2 rounded-lg border px-4 py-2.5 font-mono text-xs uppercase tracking-wider transition-all duration-300 md:inline-flex",
                pathname === "/login"
                  ? "border-primary bg-primary/15 text-primary"
                  : "border-border/80 text-muted-foreground hover:border-primary/60 hover:bg-primary/10 hover:text-primary",
              )}
            >
              <LogIn className="h-3.5 w-3.5" />
              LOGIN
            </Link>

            <div className="hidden items-center gap-2.5 rounded-full border border-border/60 bg-secondary/45 px-3 py-2 font-mono text-[11px] text-muted-foreground xl:flex">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-70" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
              </span>
              <span>status: learning</span>
            </div>

            <button
              type="button"
              onClick={() => setIsMobileMenuOpen((value) => !value)}
              className="flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-card/60 text-foreground transition-colors hover:bg-secondary lg:hidden"
              aria-label={isMobileMenuOpen ? "Закрыть меню" : "Открыть меню"}
              aria-expanded={isMobileMenuOpen}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </nav>

        <div
          className={cn(
            "overflow-hidden transition-all duration-300 lg:hidden",
            isMobileMenuOpen ? "max-h-[560px] pt-4 opacity-100" : "max-h-0 opacity-0",
          )}
        >
          <div className="rounded-xl border border-border/70 bg-card/95 p-3 shadow-xl backdrop-blur-xl">
            <div className="flex flex-col gap-1">
              {navItems.map((item) => (
                <a
                  key={item.section}
                  href={item.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center gap-3 rounded-lg px-4 py-3 font-mono text-xs uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:bg-secondary/70 hover:text-foreground"
                >
                  <span className="text-primary">&gt;</span>
                  {item.label}
                </a>
              ))}

              <Link
                href="/login"
                onClick={() => setIsMobileMenuOpen(false)}
                className="mt-1 flex items-center gap-3 rounded-lg border border-primary/40 bg-primary/10 px-4 py-3 font-mono text-xs uppercase tracking-[0.16em] text-primary"
              >
                <LogIn className="h-4 w-4" />
                LOGIN
              </Link>
            </div>

            <div className="mt-3 flex items-center justify-between border-t border-border/60 pt-3">
              <div className="flex items-center gap-2">
                <ThemeChanger />
                <ThemeToggle />
              </div>
              <div className="flex items-center gap-2 font-mono text-[11px] text-muted-foreground">
                <span className="h-2 w-2 rounded-full bg-primary" />
                status: learning
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
