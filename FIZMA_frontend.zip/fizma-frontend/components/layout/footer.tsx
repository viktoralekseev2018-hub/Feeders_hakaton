import { Mail, Send } from "lucide-react"

const contacts = [
  {
    label: "Telegram",
    handle: "@notbroken",
    href: "https://t.me/notbroken",
    icon: Send,
  },
  {
    label: "Email",
    handle: "danila@slednev.ru",
    href: "mailto:danila@slednev.ru",
    icon: Mail,
  },
]

export function Footer() {
  return (
    <footer className="px-4 pb-10 pt-20 sm:px-6 sm:pt-28">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-12 border-b border-border/60 pb-16 lg:grid-cols-[0.95fr_1.05fr] lg:items-end">
          <div>
            <p className="mb-5 font-mono text-xs uppercase tracking-[0.35em] text-primary">CONNECT</p>
            <h2 className="max-w-xl text-4xl font-bold leading-tight tracking-tight sm:text-5xl">
              Давай строить обучение <span className="text-primary">с пониманием</span>
            </h2>
            <p className="mt-6 max-w-xl text-base leading-7 text-muted-foreground">
              Вопросы о платформе, будущих курсах и материалах можно отправить в Telegram или на почту.
            </p>
          </div>

          <div className="space-y-3">
            <p className="mb-5 text-right font-mono text-xs uppercase tracking-[0.35em] text-muted-foreground">
              FIND FIZMA ELSEWHERE
            </p>
            {contacts.map((contact) => (
              <a
                key={contact.label}
                href={contact.href}
                target={contact.href.startsWith("http") ? "_blank" : undefined}
                rel={contact.href.startsWith("http") ? "noopener noreferrer" : undefined}
                className="group flex items-center justify-between rounded-xl border border-transparent bg-card/35 px-5 py-4 transition-all duration-300 hover:border-primary/40 hover:bg-primary/10"
              >
                <span className="font-mono text-sm text-muted-foreground group-hover:text-foreground">{contact.handle}</span>
                <span className="flex items-center gap-3 font-mono text-sm text-foreground">
                  {contact.label}
                  <contact.icon className="h-5 w-5 text-muted-foreground transition-colors group-hover:text-primary" />
                </span>
              </a>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-4 py-8 font-mono text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <span><span className="mr-2 inline-block h-2 w-2 rounded-full bg-primary" />made with logic &amp; practice</span>
          <span>© {new Date().getFullYear()} fizma — математика с пониманием</span>
        </div>
      </div>
    </footer>
  )
}
