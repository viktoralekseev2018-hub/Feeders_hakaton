/** @type {import('next').NextConfig} */
// Optional backend. Without this setting the frontend runs on its own.
const apiTarget = (process.env.API_BASE_URL || process.env.NEXT_PUBLIC_API_URL || "").replace(/\/+$/, "")

const nextConfig = {
  images: {
    unoptimized: true,
  },
  async rewrites() {
    if (!apiTarget) return []

    return [
      {
        source: "/api/:path*",
        destination: `${apiTarget}/api/:path*`,
      },
    ]
  },
}

export default nextConfig
