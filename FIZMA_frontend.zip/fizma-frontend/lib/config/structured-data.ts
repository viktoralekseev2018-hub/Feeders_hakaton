export function generateWebsiteStructuredData(url: string) {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "fizma",
    description:
      "Образовательная платформа по математике для учеников 6–11 классов: теория, практика, подготовка к ОГЭ и ЕГЭ.",
    url,
    inLanguage: "ru-RU",
    publisher: {
      "@type": "EducationalOrganization",
      name: "fizma",
      email: "danila@slednev.ru",
      sameAs: ["https://t.me/notbroken"],
    },
  }
}
