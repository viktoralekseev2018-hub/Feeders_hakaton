type RequestOptions = RequestInit & {
  headers?: Record<string, string>
}

export async function requestJson<T>(url: string, options: RequestOptions = {}) {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  })

  const data = (await response.json().catch(() => ({}))) as T & { message?: string }

  if (!response.ok) {
    throw new Error(data.message || "Request failed")
  }

  return data
}
