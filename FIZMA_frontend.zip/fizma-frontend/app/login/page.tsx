import { AuthForm } from "@/components/auth/auth-form"
import { CursorGlow } from "@/components/ui/cursor-glow"
import { Header } from "@/components/layout/header"

export const metadata = {
  title: "Вход",
  description: "Вход в образовательную платформу fizma.",
}

export default function LoginPage() {
  return (
    <main className="scanlines relative min-h-screen overflow-hidden">
      <CursorGlow />
      <Header />
      <div className="relative z-10 flex min-h-screen items-center justify-center px-4 pb-16 pt-28 sm:px-6 sm:pt-32">
        <AuthForm mode="login" />
      </div>
    </main>
  )
}
