import { AboutSection } from "@/components/sections/about-section"
import { ClassPractice } from "@/components/sections/class-practice"
import { CoursesSection } from "@/components/sections/courses-section"
import { CursorGlow } from "@/components/ui/cursor-glow"
import { Footer } from "@/components/layout/footer"
import { Header } from "@/components/layout/header"
import { HeroSection } from "@/components/sections/hero-section"
import { MaterialsSection } from "@/components/sections/materials-section"
import { generateWebsiteStructuredData } from "@/lib/config/structured-data"

export default function Home() {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"
  const websiteStructuredData = generateWebsiteStructuredData(baseUrl)

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteStructuredData) }}
      />
      <main className="scanlines relative min-h-screen overflow-hidden">
        <CursorGlow />
        <div className="relative z-10">
          <Header />
          <HeroSection />
          <ClassPractice />
          <CoursesSection />
          <MaterialsSection />
          <AboutSection />
          <Footer />
        </div>
      </main>
    </>
  )
}
