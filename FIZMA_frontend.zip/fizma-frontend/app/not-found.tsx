import Link from "next/link"

export default function NotFound() {
  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-xl text-center">
        <p className="font-mono text-xs uppercase tracking-[0.35em] text-primary">ERROR</p>
        <h1 className="mt-5 font-mono text-8xl font-bold text-primary sm:text-9xl">404</h1>
        <h2 className="mt-6 text-3xl font-bold">Страница не найдена</h2>
        <p className="mt-4 leading-7 text-muted-foreground">
          Возможно, адрес изменился или такой страницы ещё нет.
        </p>
        <Link
          href="/"
          className="mt-8 inline-flex rounded-lg border border-primary bg-primary/10 px-6 py-3 font-mono text-sm text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
        >
          ВЕРНУТЬСЯ НА ГЛАВНУЮ →
        </Link>
      </div>
    </main>
  )
}
