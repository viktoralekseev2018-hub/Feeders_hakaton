import type { ReactNode } from "react"
import { Geist, Geist_Mono, Space_Grotesk } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { ThemeProvider } from "@/components/ui/theme-provider"
import "./globals.css"

const geist = Geist({
  subsets: ["latin"],
  variable: "--font-geist",
  display: "swap",
})

const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-geist-mono",
  display: "swap",
})

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
  display: "swap",
})

export const metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: {
    default: "fizma — математика с пониманием",
    template: "%s | fizma",
  },
  description:
    "Образовательная платформа по математике для учеников 6–11 классов: понятная теория, практика, подготовка к ОГЭ и ЕГЭ.",
  keywords: [
    "математика",
    "ОГЭ",
    "ЕГЭ",
    "задачи по математике",
    "подготовка к экзаменам",
    "6 класс",
    "7 класс",
    "8 класс",
    "9 класс",
    "10 класс",
    "11 класс",
  ],
  authors: [{ name: "fizma" }],
  creator: "fizma",
  publisher: "fizma",
  generator: "Next.js",
  openGraph: {
    type: "website",
    locale: "ru_RU",
    url: "/",
    title: "fizma — математика с пониманием",
    description: "Понимай математику, а не заучивай её.",
    siteName: "fizma",
  },
  robots: {
    index: true,
    follow: true,
  },
  icons: {
    icon: "/icon.svg",
  },
  manifest: "/site.webmanifest",
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="ru"
      suppressHydrationWarning
      className={`${geist.variable} ${geistMono.variable} ${spaceGrotesk.variable}`}
    >
      <body className="font-sans antialiased">
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} storageKey="theme-mode">
          {children}
        </ThemeProvider>
        <Analytics />
      </body>
    </html>
  )
}
