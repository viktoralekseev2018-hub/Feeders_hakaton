"use client"

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="ru">
      <body>
        <main className="flex min-h-screen items-center justify-center px-4">
          <div className="max-w-xl text-center">
            <p className="font-mono text-xs uppercase tracking-[0.35em] text-primary">SYSTEM ERROR</p>
            <h1 className="mt-5 text-4xl font-bold">Что-то пошло не так</h1>
            <p className="mt-4 leading-7 text-muted-foreground">Попробуй повторить действие или вернуться на главную.</p>
            <button
              type="button"
              onClick={reset}
              className="mt-8 rounded-lg border border-primary bg-primary/10 px-6 py-3 font-mono text-sm text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
            >
              ПОПРОБОВАТЬ СНОВА
            </button>
          </div>
        </main>
      </body>
    </html>
  )
}
